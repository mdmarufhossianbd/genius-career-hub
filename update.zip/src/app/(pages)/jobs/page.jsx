import { PublishJobs } from '@/utils/fetchJobs';
import { IconArmchair2, IconCertificate, IconCurrentLocation, IconFileCertificate } from '@tabler/icons-react';
import Image from 'next/image';
import Link from 'next/link';

export const metadata = {
    title: 'BD Job News	|| Genius Career Hub is the largest BD Job News portal in Bangladesh',
    description: 'Genius Career Hub is the largest BD Job News portal in Bangladesh. Offering a vast range of BD Job News opportunities across various industries. Connect with top employers and find your dream job today',
    openGraph: {
        title: 'BD Job News	|| Genius Career Hub is the largest BD Job News portal in Bangladesh',
        description: 'Genius Career Hub is the largest BD Job News portal in Bangladesh. Offering a vast range of BD Job News opportunities across various industries. Connect with top employers and find your dream job today',
        url: '/jobs',
        siteName: 'BD Job News	|| Genius Career Hub is the largest BD Job News portal in Bangladesh',
        images: [
            {
                url: 'https://res.cloudinary.com/dgulbqzp8/image/upload/v1725479398/rftcpzu9sye32geejspq.webp',
                width: 1200,
                height: 630,
                alt: 'Jobs || Genius Career Hub'
            }
        ],
        type: 'website'
    }
}

const Jobs = async () => {
    const publishJobs = await PublishJobs()
    return (
        <div className='flex'>
            <div className=''>
                ads 1
            </div>
            <div className='max-w-7xl w-full mx-auto my-20'>
                <div className='grid grid-cols-1 md:grid-cols-2 gap-5'>                    
                    {
                        publishJobs?.map(job =>
                            <Link key={job._id} href={`/jobs/${job?.slug}`}>
                                <div className='p-4 bg-gradient-to-r from-[#e3ecf9] to-[#fff] border border-[#e3ecf9] hover:from-[#e3ecf9] hover:to-[#e3ecf9] duration-200 rounded flex items-center gap-5' >
                                    <div className='w-[80%] space-y-2'>
                                        <h2 className='font-medium'>{job?.title}</h2>
                                        <p className='flex gap-2 items-center'>
                                            <span className='font-medium flex items-center gap-2'><IconCurrentLocation stroke={2} /> Job Location : </span>{job?.location}
                                        </p>
                                        <p className='flex gap-2 items-center'>
                                            <span className='font-medium flex items-center gap-2'> <IconCertificate stroke={2} /> Experience : </span>{job?.experince}
                                        </p>
                                        <p className='flex gap-2 items-center'>
                                            <span className='font-medium flex items-center gap-2'> <IconArmchair2 stroke={2} /> Vacancy : </span>{job?.vacancy}
                                        </p>
                                        <p className='flex gap-2 items-center'>
                                            <span className='font-medium flex items-center gap-2'> <IconFileCertificate stroke={2} /> Education : </span>{job?.education}
                                        </p>
                                    </div>
                                    <div className='w-[20%]'>
                                        <Image className='w-auto h-auto rounded' src={job?.companyInfo?.logo} alt={job?.title} width={300} height={300} priority unoptimized />
                                    </div>
                                </div>
                            </Link>
                        )
                    }
                </div>
            </div>
            <div className='sticky top-0'>
                ads 2
            </div>
        </div>
    );
};

export default Jobs;